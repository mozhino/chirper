<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['chirp']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['chirp']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="card bg-base-100">
    <div class="card-body">
        <div class="flex space-x-3">
            <div class="avatar">
                <div class="size-10 rounded-full">
                    <img src="https://avatars.laravel.cloud/<?php echo e(urlencode($chirp->user->email)); ?>?vibe=ocean"
                        alt="<?php echo e($chirp->user->name); ?>'s avatar" class="rounded-full" />
                </div>
            </div>

            <div class="flex-1 min-w-0">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-1">
                        <p class="text-sm font-semibold">
                            <?php echo e($chirp->user->name); ?>

                        </p>
                        <span class="text-base-content/60">·</span>
                        <p class="text-sm text-base-content/60">
                            <?php echo e($chirp->created_at->diffForHumans()); ?>

                        </p>
                        <?php if($chirp->updated_at->gt($chirp->created_at->addSeconds(5))): ?>
                            <span class="text-base-content/60">·</span>
                            <span class="text-sm text-base-content/60 italic">edited</span>
                        <?php endif; ?>
                    </div>

                    <?php if(auth()->check() && auth()->id() === $chirp->user_id): ?>
                        <!-- Edit/Delete Buttons -->
                        <div class="flex gap-1">
                            <a href="/chirps/<?php echo e($chirp->id); ?>/edit" class="btn btn-ghost btn-xs">
                                Edit
                            </a>
                            <form method="POST" action="/chirps/<?php echo e($chirp->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    onclick="return confirm('Are you sure you want to delete this chirp?')"
                                    class="btn btn-ghost btn-xs text-error">
                                    Delete
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>

                <p class="mt-1">
                    <?php echo e($chirp->message); ?>

                </p>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\chirper\resources\views/components/chirp.blade.php ENDPATH**/ ?>